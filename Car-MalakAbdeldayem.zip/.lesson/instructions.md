# Instructions  

Consider the Car class, whose incomplete class has been provided.  Provide code to solve the parts below. **Your solution should not reimplement the functionality provided by methods given in the problem definition, or by the methods written in the previous parts of the problem.**


```java
public class Car{
	
  private double mpg;
  private double mileage;
  private double tankCapacity;
  private double gasInTank;

  /**
    Constructs a car.
    @param miles miles per gallon that car gets
    @param milesOnCar total mileage on car
    @param gasTankHolds amount of gas the tank holds
    @param gasTankHas gas in tank now
  */

  public Car (double miles, double milesOnCar, double gasTankHolds, double gasTankHas){
    mpg = miles;
    mileage = milesOnCar;
    tankCapacity = gasTankHolds;
    gasInTank = gasTankHas;
  }

  /**
    Returns the gas needed to drive miles (based on mpg).
    @param numMiles the number of miles to be driven
    @return gas needed to drive numMiles miles
  */
  public double gasNeeded ( double numMiles){
    // TODO: Part A
  }

  /**
    Returns true if the car has enough gas in the tank to drive numMiles miles, otherwise returns false.
    @param numMiles miles t obe driven
    @return true if gas in tank is enough to drive numMiles miles; false otherwise
  */
  public boolean enoughGas (double numMiles){
    // TODO: Part B
  }

  /**
    If tank is less than half full, fills tank and updates gasInTank, otherwise does nothing.
  */
  public void getGas(){
    // TODO: Part C
  }
  
  /** 
    Updates mileage and gasInTank to reflect numMiles being driven.
    @param numMiles number of miles driven
  */
  public void drive (double numMiles){
    // TODO: Part D
  }

  /**
    Returns the current mileage on the car.
    @return mileage on car
  */
  public double getMileage()   { . . . }

  /**
    Returns the amount of gas in the gas tank.
    @return amount of gas in tank
  */
  public double getGasInTank()   { . . . }

}
```


  ## Problems

### Part A
  Write method `gasNeeded` that will return a `double` indicating the number of gallons of gas needed to make a trip that is `numMiles` long where `numMiles` is the explicit parameter of `gasNeeded`.  Use the method header below to write gasNeeded.
```java
public double gasNeeded (double numMiles)
{}
```

### Part B
Write a method `enoughGas` that is passed a `double` parameter `numMiles`.  The method `enoughGas` will return `true` if there is enough gas in the tank to drive `numMiles` miles.  If there is not enough gas in the tank, `enoughGas` will return `false`.  Use the method header below to write `enoughGas`.

```java
public boolean enoughGas (double numMiles){
  }
```

### Part C
Write the method `getGas` that will fill the gas tank of the car if it is less than half full.  If the car has half of a tank of gas or more, `getGas` does nothing.  Use the method header below to write `getGas`.

```java
public void getGas(){
}
```

### Part D
Write the method 'drive' whose parameter is the intended number of miles the car is to travel.  However, the gas tank in the car contains a finite amount of gas.  If the car has enough gas to travel the specified number of miles, the appropriate private instance variables should be updated.  If the car does not have enough gas to make the requested trip, the car should travel until it runs out of gas.  The appropriate private variables should be updated. For example suppose that a client program constructs a Car with the following statement:

```java
    Car myMini = new Car(25, 600, 20, 20);
```

#### Examples of calls to drive are listed in the table below:

| Before call to drive |         |                    | After call to drive |         |
|----------------------|---------|--------------------|---------------------|---------|
| gasInTank            | mileage | Call to drive      | gasInTank           | mileage |
|----------------------|---------|--------------------|---------------------|---------|
| 20                   | 600     | myMini.drive(100)  | 16                  | 700     |
| 20                   | 600     | myMini.drive(0)    | 20                  | 600     |
| 20                   | 600     | myMini.drive(1000) | 0                   | 1100    |

Use the following method header to write your method.

```java
public void drive (double numMiles){
}
```


  